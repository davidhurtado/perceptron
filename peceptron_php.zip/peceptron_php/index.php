<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>PERCEPTRON</title>
        <link href="materialize/css/materialize.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/plotly-latest.min.js" type="text/javascript"></script>
        <script src="materialize/js/materialize.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
        include('Perceptron.php');
        $bias = rand(-10, 10);
        $pesosIniciales = [rand(-10, 10), rand(-10, 10)];
        $perceptron = new Perceptron(2, $bias); // (2, 0.5) defino el tamaño del vecto, aprendizaje

        $data = [];
        $status = false;
        echo "<script type='text/javascript'>"
        . "grupo1_x = []; "
        . "grupo1_y = [];"
        . "grupo2_x = [];"
        . "grupo2_y = [];"
        . "valorX =0;"
        . "valorY = 0;" .
        "var laygrupo = {
    xaxis: {range: [-20, 20]},
    yaxis: {range: [-20, 20]}
};"
        . "</script>";
        if (isset($_POST['submit'])) {

            if (isset($_POST['bias'])) {
                $bias = $_POST['bias'];
            }
            if (isset($_POST['pesox']) && isset($_POST['pesoy'])) {
                $pesosIniciales = [$_POST['pesox'], $_POST['pesoy']]; // en x and y
            }
            $perceptron->setWeight($pesosIniciales);
            $perceptron->setBias($bias);
            $grupo1 = $_POST['grupo1'];
            $grupo2 = $_POST['grupo2'];
            $i = 0;
            $v_aux = [];
            $ind = 0;
            foreach ($grupo1 as $g1) {
                $v_aux[$i] = $g1;
                if ($i == 1) {
                    array_push($data, [[$v_aux[0], $v_aux[1]], 1]);
                    $i = -1;
                    echo "<script type='text/javascript'>grupo1_x[" . $ind . "] =" . $v_aux[0] .
                    "; grupo1_y[" . $ind . "] =  " . $v_aux[1] . ";</script>";
                }
                $ind++;
                $i++;
            }
            $i = 0;
            $ind = 0;
            foreach ($grupo2 as $g) {
                $v_aux[$i] = $g;
                if ($i == 1) {
                    array_push($data, [[$v_aux[0], $v_aux[1]], -1]);
                    $i = -1;
                    echo "<script type='text/javascript'>grupo2_x[" . $ind . "] =" . $v_aux[0] .
                    "; grupo2_y[" . $ind . "] =  " . $v_aux[1] . ";</script>";
                }
                $ind++;
                $i++;
            }
            $perceptron->trainer($data);
            echo "<script type='text/javascript'>valorX =" . (-$perceptron->bias / $perceptron->weightVector[0]) . ";"
            . "valorY = " . (-$perceptron->bias / $perceptron->weightVector[1]) . ";</script>";
            $status = true;
        }
        ?>
        <div class="container">  
            <h1 align="center">PERCEPTRON</h1> 
            <div class="col-lg-6">
                <h3 align="center">Valores</h3>  
                <form method="post" >
                    <div class="row center">
                        <div class="col s6">
                            <h3 align="center">Grupo 1 </h3>  
                            <div class="form-group" id="grupo1">  
                                <button type="button" name="addgrupo1" id="addgrupo1" class="btn btn-success">Agregar</button>
                                <br><br>
                                <div class="table-responsive">  
                                    <table class="responsive-table" id="tablagrupo1">  
                                        <tr>  
                                            <td><input type="text" name="grupo1[]" placeholder="x" class="form-control name_list" /></td> 
                                            <td><input type="text" name="grupo1[]" placeholder="y" class="form-control name_list" /></td>
                                        </tr>  
                                    </table>  

                                </div>  

                            </div> 
                        </div>
                        <div class="col s6">
                            <h3 align="center">Grupo -1</h3>
                            <div class="form-group" id="grupo2">  
                                <button type="button" name="addgrupo2" id="addgrupo2" class="btn btn-success">Agregar</button><br><br>
                                <div class="table-responsive">  
                                    <table class="responsive-table" id="tablagrupo2">  
                                        <tr>  
                                            <td><input type="text" name="grupo2[]" placeholder="x" class="form-control name_list" /></td>
                                            <td><input type="text" name="grupo2[]" placeholder="y" class="form-control name_list" /></td>
                                        </tr>  
                                    </table>  

                                </div>   
                            </div> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="checkbox col s5">
                            <div class="switch">
                                Ingresar bias
                                <label>
                                    Off
                                    <input type="checkbox" id="chbias">
                                    <span class="lever"></span>
                                    On
                                </label>

                            </div>
                            <div class="col s5">
                                <input type="text" id="bias" name="bias" class="form-control" hidden>
                            </div>
                        </div>
                        <div class="checkbox col s5">
                            <div class="switch">
                                Ingresar pesos
                                <label>
                                    Off
                                    <input type="checkbox" id="chpesos">
                                    <span class="lever"></span>
                                    On
                                </label>
                            </div>
                            <div class="col s5">
                                <input type="text" id="pesox" name="pesox" placeholder="x" class="form-control" hidden>
                            </div>
                            <div class="col s5">
                                <input type="text" id="pesoy" name="pesoy" placeholder="y" class="form-control" hidden>
                            </div>
                        </div>
                    </div>
                    <div class="center"><input type="submit" name="submit" id="submit" class="btn btn-info" value="Calcular" /></div>

                </form>
                <!-- Modal Structure -->
                <div id="modal1" class="modal col s12">
                    <div class="modal-content col s12">
                        <h3 align="center">RESULTADOS</h3>
                        <div class="col-lg-12" style="border: 2px solid steelblue; padding: 12px">
                            <div class="row">
                                <div class="col s4">
                                    <label for="ex1">Peso resultante x</label>
                                    <input class="form-control" value="<?= $perceptron->weightVector[0] ?>" type="text">
                                </div>
                                <div class="col s4">
                                    <label for="ex2">Peso resultante y</label>
                                    <input class="form-control" value="<?= $perceptron->weightVector[1] ?>" type="text">
                                </div>
                                <div class="col s4">
                                    <label for="ex3">Bias resultante</label>
                                    <input class="form-control" value="<?= $perceptron->bias ?>" type="text">
                                </div>
                            </div><br>
                            <div class="row">
                                <div class="col s4">
                                    <label for="ex4">Punto x</label>
                                    <input class="form-control" value="<?= -$perceptron->bias / $perceptron->weightVector[0] ?>" id="puntoXfinal" type="text">
                                </div>
                                <div class="col s4">
                                    <label for="ex5">Punto y</label>
                                    <input class="form-control" value="<?= -$perceptron->bias / $perceptron->weightVector[1] ?>" id="puntoYfinal" type="text">
                                </div>
                            </div>   <br>
                            <div class="row">
                                <div class="col s4"> 
                                    <button type="button" id="agregar_prueba" class="btn btn-success">Probar</button>
                                </div>
                                <br><br>
                                <div class="col s4"> 
                                    <input type="text" id="test_x" placeholder="x" class="form-control" /> 
                                </div>
                                <div class="col s4"> 
                                    <input type="text" id="test_y" placeholder="y" class="form-control" />
                                </div>  
                            </div> 
                            
                            <?php
                            $test = [-5, 6];
                            echo "<br>";
                            echo "Respuesta para(" . $test[0] . "," . $test[1] . ") Pertenece al grupo: " . $perceptron->test($test) . "\n";
                            ?>
                        </div><!-- end nested row -->
                        <div class="col-lg-6">
                            <div id="tester" style="width:600px;height:600px;"></div>
                        </div>
                        <script src="js/grafica.js" type="text/javascript"></script>
                            <script type="text/javascript">
                                grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY);
                            </script>
                    </div>
                </div>
            </div>
        </div>  

        <?php if ($status) echo "<script type='text/javascript'>$('#modal1').openModal();</script>"; ?>
        <script src="js/tabla.js" type="text/javascript"></script>
        
        <script type="text/javascript">
                                $('#agregar_prueba').click(function () {
                                    testx = parseFloat($('#test_x').val());
                                    testy = parseFloat($('#test_y').val());
                                    <?php
                                    $tx = "document.write(testx);";
                                    $ty = "document.write(testy);";
                                    $test = [(double)$tx, (double)$ty];
                                    ?>
                                    total_prueba = <?= $perceptron->test([(double)$tx,(double)$ty]) ?>;
                                    if (total_prueba == 1) {
                                        grupo1_x[2] = testx;
                                        grupo1_y[2] = testy;
                                    } else {
                                        console.log(-1);
                                        grupo2_x[2] = testx;
                                        grupo2_y[2] = testy;
                                    }
                                    //console.log( grupo1_x +" "+grupo1_x);
                                    grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY);
                                });
        </script>
        <div style="padding-bottom: 40px"></div>
    </body>
</html>
