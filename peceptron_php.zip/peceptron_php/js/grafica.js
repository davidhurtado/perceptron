function grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY) {
var trace1 = {
    x: grupo1_x, //[2, 0, -2, 0],
    y: grupo1_y, //[1, -1, 1, 2],
    name: "Grupo 1",
    mode: "markers"// esto crea los puntos
};
var trace2 = {
    x: grupo2_x, //[-1, 4],
    y: grupo2_y, //[3, 2],
    name: "Grupo -1",
    mode: 'markers'
};
x1 = 100;
y1 = (((valorY - 0) / (0 - valorX)) * (x1 - valorX)) + 0;
x2 = -100;
y2 = (((valorY - 0) / (0 - valorX)) * (x2 - valorX)) + 0;
var puntos_de_corte = {
    x: [valorX, 0, x1, x2],
    y: [0, valorY, y1, y2],
    name: "Linea Cortante",
    type: 'scatter'
};
data = [trace1, trace2, puntos_de_corte];
Plotly.newPlot('tester', data, laygrupo);
}