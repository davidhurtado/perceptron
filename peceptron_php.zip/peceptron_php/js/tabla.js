$(document).ready(function () {
    // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
   // $('#modal1').leanModal();
          
    $('#bias').hide();
    $('#pesox').hide();
    $('#pesoy').hide();
    
$('#chbias').change(function () {
    if (this.checked) {
        $('#bias').fadeIn('slow');
    } else {
        $('#bias').fadeOut('slow');
    }


});
$('#chpesos').change(function () {
    if (this.checked) {
        $('#pesox').fadeIn('slow');
        $('#pesoy').fadeIn('slow');
    } else {
        $('#pesox').fadeOut('slow');
        $('#pesoy').fadeOut('slow');

    }
});
    var i = 1;
    var j = 1;
    $('#addgrupo1').click(function () {
        i++;
        $('#tablagrupo1').append('<tr id="row' + i + '">\n\
            <td>\n\
                <input type="text" name="grupo1[]" placeholder="x" class="form-control name_list" />\n\
           </td>\n\
            <td>\n\
                <input type="text" name="grupo1[]" placeholder="y" class="form-control name_list" /></td>\n\
            <td>\n\
            <button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button>\n\
            </td></tr>');
    });
    $('#addgrupo2').click(function () {
        i++;
        j++;
        $('#tablagrupo2').append('<tr id="row' + i + '">\n\
            <td>\n\
                <input type="text" name="grupo2[]" placeholder="x" class="form-control name_list" />\n\
           </td>\n\
            <td>\n\
                <input type="text" name="grupo2[]" placeholder="y" class="form-control name_list" /></td>\n\
            <td>\n\
            <button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button>\n\
            </td></tr>');
    });
    $(document).on('click', '.btn_remove', function () {
        var button_id = $(this).attr("id");
        $('#row' + button_id + '').remove();
    });

    
});

