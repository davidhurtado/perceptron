<?php

class Perceptron {

    protected $error;
    protected $salida;// esto hace refencia a "a"
    static public $bias;
    protected $vectorLength;
    static public $weightVector;
    protected $satisface = false;

    function __construct($vectorLength, $bias) {
        //Validacion
        if ($vectorLength < 1) {
            throw new InvalidArgumentException();
        }
        $this->vectorLength = $vectorLength;
        $this->bias = $bias;
    }

    public function trainer($data) {
        //si no se ha asignado el peso se genera aleatoriamente
        if (empty($this->weightVector)) {
            Self::setWeightRandom();
        }

        // si no satisface vuelve a entrenar
        while (!$this->satisface) {
            foreach ($data as $trainSample) {
                Self::train($trainSample[0], $trainSample[1]);
            }

            //prueba de pesos
            $status = true;
            foreach ($data as $trainSample) {
                if (Self::test($trainSample[0]) != $trainSample[1]) {
                    $status = false;
                }
            }
            if ($status == true) {
                $this->satisface = true;
            }
        }
        //echo "<script  type=\"text/javascript\">$('#modal1').openModal();</script>";
        echo 'Los pesos son : ' . "<br>";
        echo " X = " . -$this->bias/$this->weightVector[0] . " Y = " . -$this->bias/$this->weightVector[1];
       echo("<br>");
       echo("y la bias es: ");
        echo($this->bias . "\n");
        
    }

    public function train($input, $result) {
        //Validacion
        if (!is_array($input) || ($result != 1 && $result != -1)) {
            throw new InvalidArgumentException();
        }
        $salida = Self::test($input);
        if ($salida != $result) {
            //si a no es igual al grupo q se espera cambiamos los pesos
            $this->error = (int) $result - (int) $salida;
            for ($i = 0; $i < $this->vectorLength; $i++) {
                $this->weightVector[$i] = $this->weightVector[$i] + ($this->error) * $input[$i];
            }
            $this->bias = $this->bias + $this->error;
        }
    }

    public function test($input) {
        //Validacion
        if (!is_array($input) || count($input) != $this->vectorLength) {
            throw new InvalidArgumentException();
        }

        $testResult = $this->dotVectors($this->weightVector, $input) + $this->bias;
        return $testResult >= 0 ? 1 : -1;
    }

    private function dotVectors($vector1, $vector2) {
        $total = 0;
        $dim = count($vector1);
        for ($i = 0; $i < $dim; $i++) {
            $total += $vector1[$i] * $vector2[$i];
        }
        return $total;
    }

    public function setWeight($weightVector) {
        //Validacion
        if (!is_array($weightVector) || count($weightVector) != $this->vectorLength) {
            throw new \InvalidArgumentException();
        }
        $this->weightVector = $weightVector;
    }
        public function setBias($bias) {
        $this->bias = $bias;
    }

    public function setWeightRandom() {
        //si no ingresa el peso se hara aleatorio
        for ($i = 0; $i < $this->vectorLength; $i++) {
            $this->weightVector[$i] = rand(0, 10);
        }
    }

}
