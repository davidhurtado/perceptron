//Return the raw activation value for a giving trainingSet
function getSum(weights, puntos, bias) {
    var sum = 0;
    for (var i = 0; i < puntos.length; i++) {
        sum += weights[i] * puntos[i];
    }
    sum += bias;
    return sum;
}

//Activation function
function hadlines(value) {
    return (value >= 0) ? 1 : -1;
}
var grupo1 = [];
var grupo2 = [];
var grupo1_x = [];
var grupo1_y = [];
var grupo2_x = [];
var grupo2_y = [];
var data = [];
var laygrupo = {
    xaxis: {range: [-20, 20]},
    yaxis: {range: [-20, 20]}
};
if ($("#checkbox_pesos").change()) {

}
var w = [-0.7, 0.2];
var bias = 0.5;

$('#checkbox_bias').change(function () {
    if (this.checked) {
        $('#bias').fadeIn('slow');
    } else {
        $('#bias').fadeOut('slow');
    }


});
$('#checkbox_pesos').change(function () {
    if (this.checked) {
        $('#pesox').fadeIn('slow');
        $('#pesoy').fadeIn('slow');
    } else {
        $('#pesox').fadeOut('slow');
        $('#pesoy').fadeOut('slow');

    }
});

var error = 0;
$('#submit').click(function () {
    if ($("#checkbox_pesos").is(':checked')) {
        w = [parseFloat($('#pesox').val()), parseFloat($('#pesoy').val())];
    } else {
        w = [Math.random() * 20 - Math.random() * 20, Math.random() * 10 - Math.random() * 10];
    }
    if ($("#checkbox_bias").is(':checked')) {
        bias = parseFloat($("#bias").val());
    } else {
        bias = Math.random() * 10 - Math.random() * 10;
    }
    grupo1 = [];
    grupo2 = [];
    i = 0;
    var data_g1 = $('#grupo1').serializeArray().reduce(function (obj, item) {
        obj[item.name] = item.value;
        grupo1[i] = obj[item.name];
        i++;
        return obj;
    }, {});
    i = 0;

    var data_g2 = $('#grupo2').serializeArray().reduce(function (obj, item) {
        obj[item.name] = item.value;
        grupo2[i] = obj[item.name];
        i++;
        return obj;
    }, {});

    grupo1_x = [];
    grupo1_y = [];
    for (x = 0, ind = 0; x < grupo1.length; x = x + 2, ind++) {
        grupo1_x[ind] = grupo1[x];
        grupo1_y[ind] = grupo1[x + 1];
    }

    grupo2_x = [];
    grupo2_y = [];
    for (x = 0, ind = 0; x < grupo2.length; x = x + 2, ind++) {
        grupo2_x[ind] = grupo2[x];
        grupo2_y[ind] = grupo2[x + 1];
    }
    var test = [];
    for (i = 0; i < grupo1_x.length; i++) {
        test.push({puntos: [grupo1_x[i], grupo1_y[i]], grupo: 1});
    }
    for (i = 0; i < grupo2_x.length; i++) {
        test.push({puntos: [grupo2_x[i], grupo2_y[i]], grupo: -1});
    }
    //console.log(test);
    var total;
    var cont_error = 0;
    for (var i = 0; i < test.length; i++) {
        total = hadlines(getSum(w, test[i].puntos, bias));
        //console.log("puntos -> "+test[i].puntos + " grupo: " + test[i].grupo + " total: " + total);
        if (total != test[i].grupo) {
            error = test[i].grupo - total;
            w = [w[0] + (error * test[i].puntos[0]), w[1] + (error * test[i].puntos[1])];
            bias = bias + error;
            //console.log("error: " + error + " peso nuevo: " + w+" bias -> "+bias);
            cont_error += 1;
        }
        if ((i + 1) == test.length && cont_error > 0) {
            i = -1;
            cont_error = 0;
        }
    }
    //console.log("bias: " + bias + " peso: " + w);

    valorX = -bias / w[0];
    valorY = -bias / w[1];

    $("#pesoXfinal").val(w[0].toFixed(2));
    $("#pesoYfinal").val(w[1].toFixed(2));
    $("#biasFinal").val(bias.toFixed(2));
    $("#puntoXfinal").val(valorX.toFixed(2));
    $("#puntoYfinal").val(valorY.toFixed(2));
    grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY);
});
$('#addprueba').click(function () {
    testx = parseFloat($('#testx').val());
    testy = parseFloat($('#testy').val());
    total_prueba = hadlines(getSum(w, [testx, testy], bias));
    if (total_prueba == 1) {
        grupo1_x[ind] = testx;
        grupo1_y[ind] = testy;
    } else {
        grupo2_x[ind] = testx;
        grupo2_y[ind] = testy;
    }
    //console.log( grupo1_x +" "+grupo1_x);
    grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY);
});
function grafica(grupo1_x, grupo1_y, grupo2_x, grupo2_y, valorX, valorY) {
    var trace1 = {
        x: grupo1_x, //[2, 0, -2, 0],
        y: grupo1_y, //[1, -1, 1, 2],
        name: "Grupo 1",
        mode: "markers"// esto crea los puntos
    };
    var trace2 = {
        x: grupo2_x, //[-1, 4],
        y: grupo2_y, //[3, 2],
        name: "Grupo 2",
        mode: 'markers'
    };
    x1 = 100;
    y1 = (((valorY - 0) / (0 - valorX)) * (x1 - valorX)) + 0;
    x2 = -100;
    y2 = (((valorY - 0) / (0 - valorX)) * (x2 - valorX)) + 0;
    var puntos_de_corte = {
        x: [valorX, 0, x1, x2],
        y: [0, valorY, y1, y2],
        name: "Linea Cortante",
        type: 'scatter'
    };
    data = [trace1, trace2, puntos_de_corte];
    Plotly.newPlot('tester', data, laygrupo);
}
Plotly.newPlot('tester', data, laygrupo);