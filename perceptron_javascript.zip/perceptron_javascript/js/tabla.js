$(document).ready(function () {
    $('#bias').hide();
    $('#pesox').hide();
    $('#pesoy').hide();
    var i = 1;
    var j = 1;
    $('#addgrupo1').click(function () {
        i++;
        $('#tablagrupo1').append('<tr id="row' + i + '">\n\
            <td>\n\
                <input type="text" name="g1_x' + i + '" placeholder="x" class="form-control name_list" />\n\
           </td>\n\
            <td>\n\
                <input type="text" name="g1_y' + i + '" placeholder="y" class="form-control name_list" /></td>\n\
            <td>\n\
            <button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button>\n\
            </td></tr>');
    });
    $('#addgrupo2').click(function () {
        i++;
        j++;
        $('#tablagrupo2').append('<tr id="row' + i + '">\n\
            <td>\n\
                <input type="text" name="g2_x' + j + '" placeholder="x" class="form-control name_list" />\n\
           </td>\n\
            <td>\n\
                <input type="text" name="g2_y' + j + '" placeholder="y" class="form-control name_list" /></td>\n\
            <td>\n\
            <button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button>\n\
            </td></tr>');
    });
    $(document).on('click', '.btn_remove', function () {
        var button_id = $(this).attr("id");
        $('#row' + button_id + '').remove();
    });

    
});

