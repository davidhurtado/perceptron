"""
PUCESE 2016 - I
Alumno: David Hurtado Chichande
Inteligencia Artificial 2
7mo de Sistemas y Computación
Perceptron.
"""
from matplotlib.pylab import *
from heapq import merge
# modulo local
import generate_data
import perceptron
#g1=[[2,1,1], [0,-1, 1]] #son datos fijos
#g2=[[-2,1,-1], [0,2, -1]] #son datos fijos
g1 = generate_data.generateData(10) # generacion valores aleatorios
g2 = generate_data.generateData(10) # generacion valores aleatorios
#gg=list(merge(g1, g2)) #union de los grupos para ser evaluados en el perceptron
p = perceptron.Perceptron() # llamando la funcion del perceptron
p.train(g1)
#Prueba de Perceptron
for x in g2:
    #r = p.response(x)
    r = x[2]
    if r != x[2]: # en la 3ra posicion se guarda el grupo
        print ('no tiene grupo')
    if r == 1: #clasificacion de puntos por grupo
        plot(x[0], x[1], 'ob')# 'ob'-> puntos azules
    else:
        plot(x[0], x[1], 'or')# 'or'-> puntos rojos
# separacion de las lineas del plot
# en el centro de las lineas estan las coordenadas originales
# separacion de la linea ortogonal a w
n = norm(p.w) # longitud del vector p.w -> indica el peso
ww = p.w / n # la unidad del vector
p1 = [ww[1], -ww[0]]
p2 = [-ww[1], ww[0]]
plot([p1[0], p2[0]], [p1[1], p2[1]], '--k')
print ('Puntos deseados',ww)
show()
