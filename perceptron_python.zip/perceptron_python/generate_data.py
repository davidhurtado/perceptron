#by David Hurtado Chichande
import numpy as np #importando la libreria para numeros aleatorios

def generateData(n): #funcion para generar los pesos
    xb = (np.random.rand(n) * 2 -1) / 2 - 0.5
    yb = (np.random.rand(n) * 2 -1) / 2 + 0.5
    xr = (np.random.rand(n) * 2 -1) / 2 + 0.5
    yr = (np.random.rand(n) * 2 -1) / 2 - 0.5
    inputs = []
    inputs.extend([[xb[i], yb[i], 1] for i in range(n)])# grupo 1
    print('antes -> ',inputs)
    inputs.extend([[xr[i], yr[i], -1] for i in range(n)])# grupo -1
    print('despues -> ',inputs)
    return inputs
