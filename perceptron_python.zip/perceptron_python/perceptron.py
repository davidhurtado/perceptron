#by David Hurtado Chichande
import random

class Perceptron(object):
    """_autoload del perceptron"""
    def __init__(self):
        super(Perceptron, self).__init__()
        self.w = [random.random() * 2 - 1 for _ in range(2)] # pesos
        self.learningRate = 0.1

    def response(self, x):
        """ salida del perceptron"""
        #y = x[0] * self.w[0] + x[1] * self.w[1] # punto del producto entre w y x
        y = sum([i * j for i, j in zip(self.w, x)])
        if y >= 0:
            return 1
        else:
            return -1

    def updateWeights(self, x, iterError):
        """
        actualiza los pesos, w en tiempo de t+1 es
        w(t+1) = w(t) + tasaDeAprendizaje * (d - r) * x
        Error es (d - r)
        """
        # self.w[0] += self.learningRate * iterError * x[0]
        # self.w[1] += self.learningRate * iterError * x[1]
        self.w = \
            [i + self.learningRate * iterError * j for i, j in zip(self.w, x)]

    def train(self, data):
        """
        Todos los valores de los datos vectoriales.
        Cada vector de datos deben tener tres elementos.
        El tercer elemento(x[2]) debe ser la etiqueta(salida deseada)
        """
        learned = False #inicio par iteractuar
        iteration = 0
        while not learned:
            globalError = 0.0
            for x in data: # para cada muestra
                r = self.response(x)
                if x[2] != r: # si existe una respuesta incorrecta
                    iterError = x[2] - r # respuesta deseada -> actual respuesta
                    self.updateWeights(x, iterError) #actualiza el peso deseado
                    globalError += abs(iterError) #obtiene el erorr
            iteration += 1
            if globalError == 0.0 or iteration >= 100: # criterios de paradas
                #print ('iterations: %s' % iteration)
                learned = True # dejar de iteractuar
